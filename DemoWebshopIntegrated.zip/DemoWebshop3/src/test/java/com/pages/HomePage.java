package com.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

	WebDriver driver;
	public HomePage(WebDriver driver) {
		this.driver=driver;
	}
	
	By register= By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");
	By loginlink = By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a");
	By eid= By.xpath("//*[@id=\"newsletter-email\"]");
	By subscribe_btn=By.xpath("//*[@id=\"newsletter-subscribe-button\"]");
	public void launch_website() throws IOException {
	
	String filename= "C:\\\\Users\\\\3lok\\\\Desktop\\\\selenium\\\\DemoWebshop3\\\\src\\\\test\\\\resources\\\\config_property\\\\configuration.property";
	FileInputStream config_file= new FileInputStream(filename);
	Properties prop = new Properties();
	prop.load(config_file);

	driver.get(prop.getProperty("url"));
	
	}
	public void click_login() {
		driver.findElement(loginlink).click();
	}
	public void click_register() {
		driver.findElement(register).click();
	}
	public void enter_emailid(String emailid)
	{
		driver.findElement(eid).sendKeys(emailid);
	}
	public void click_subscribe()
	{
		driver.findElement(subscribe_btn).click();
	}
	
	
}
