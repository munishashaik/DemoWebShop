package com.stepdef;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.baseclass.library;
import com.excelutil.excelutil;
import com.pages.loginpage;
import com.pages.searchpage;
import com.selutil.selutil;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class searchstepdef extends library {
	
	//selutil util;
	Logger LOG = Logger.getLogger("devpinoyLogger");
	
	
	searchpage sp;
	@Given("^I want to launch the searchpage$")
	public void i_want_to_launch_the_browser() throws IOException  {
		 
	LaunchBrowser();
		System.out.println("browser is launched");
		
	   }
	

@When("^Search page is opened$")
	public void search_page_is_opened() throws IOException  {
	selutil util= new selutil(driver);
		util.Screenshot("C:\\Users\\lenovo\\Desktop\\munisha\\selenium\\DemoWebShop\\src\\test\\resources\\Screenshots\\searchpage.png");
	    System.out.println("screenshot is successfully taken");
	    sp= new searchpage(driver);
	    excelutil ex= new excelutil();
	    sp.do_login(ex.emailid1(1), ex.password1(1));
	    
	 }

	@Then("^I enter the desired \"([^\"]*)\"$")
	public void i_enter_the_desired(String productname){
		sp= new searchpage(driver);
		sp.enter_text(productname);
		LOG.info("product to be searched is entered");
		
	    
	}

	@Then("^I click the search button$")
	public void i_click_the_search_button() {
		sp= new searchpage(driver);
		sp.clicksearch_btn();
		LOG.info("desired product is searched");
	   
	}

	@Then("^The product page is opened$")
	public void the_product_page_is_opened() {
		selutil util;
		util= new selutil(driver);
		util.Screenshot("C:\\Users\\lenovo\\Desktop\\munisha\\selenium\\DemoWebShop\\src\\test\\resources\\Screenshots\\productpage.png");
	    System.out.println("screenshot is successfully taken");
	
	}




}
