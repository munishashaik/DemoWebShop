package com.testrunner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		
		features = "src/test/resources/Features/Testcase.feature",
		 glue = {"com.stepdef"},    
plugin = {"pretty", "html:reports/cucumber-html-report","json:reports/cucumber-html-report/jsonreport",
		 "junit:target/cucumber-junit-report",
	        		"com.cucumber.listener.ExtentCucumberFormatter:reports/Extentreports/Extentreport.html"},
	       tags = {"@tc_01,@tc_02,@tc_03,@tc_04,@tc_05,@tc_06"},
	       
	       monochrome = true
	        

		
		
		
		
		
		)




public class testrunner {
	/*@AfterClass
	public static void extentreport()
	{
		Reporter.loadXMLConfig("src\\test\\resources\\Reports\\extend-config.xml");
		Reporter.setSystemInfo("user",System.getProperty("user.name"));
		Reporter.setSystemInfo("os","Windows");
		Reporter.setTestRunnerOutput("Sample test runner output message");
	}*/


}
