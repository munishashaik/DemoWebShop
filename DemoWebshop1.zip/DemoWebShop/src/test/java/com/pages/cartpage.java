package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class cartpage {
 
	WebDriver driver;
	By book_btn= By.xpath("/html/body/div[4]/div[1]/div[4]/div[1]/div[1]/div[2]/ul/li[1]/a");
	By cart_btn=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[2]/div[3]/div[2]/input");
	By shoppingcart_btn=By.xpath("//*[@id=\"topcartlink\"]/a/span[1]");
	
	
	
	public cartpage(WebDriver driver) {
		
		this.driver=driver;
	}
	
	public void click_books()
	{
		driver.findElement(book_btn).click();
	}
	public void click_cart()
	{
		driver.findElement(cart_btn).click();
	}
	public void click_shoppingcart()
	
	{
		driver.findElement(shoppingcart_btn).click();
	}
}
