package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Newsletterpage {
WebDriver driver;
By eid= By.xpath("//*[@id=\"newsletter-email\"]");
By subscribe_btn=By.xpath("//*[@id=\"newsletter-subscribe-button\"]");

public Newsletterpage(WebDriver driver)
{
	this.driver = driver;
	
}
public void enter_emailid(String emailid)
{
	driver.findElement(eid).sendKeys(emailid);
}
public void click_subscribe()
{
	driver.findElement(subscribe_btn).click();
}


}
