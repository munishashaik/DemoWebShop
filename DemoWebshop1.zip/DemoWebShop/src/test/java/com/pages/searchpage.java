package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class searchpage {
	WebDriver driver;
	By eid1=By.id("Email");
	By pwd1=By.id("Password");
	By login_btn1= By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input");
	By before_loginbtn1=By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a");
	
	By pname=By.xpath("//*[@id=\"small-searchterms\"]");
	By search_btn= By.xpath("/html/body/div[4]/div[1]/div[1]/div[3]/form/input[2]");
	public searchpage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
	public void before_clickloginbtn_excel()
	{
		driver.findElement(before_loginbtn1).click();
	}
public void enter_emailid_excel(String emailid1)
{
	driver.findElement(eid1).sendKeys(emailid1);
}
public void enter_password_excel(String password1)
{
	driver.findElement(pwd1).sendKeys(password1);
}
public void clicklogin_btn_excel()
{
	driver.findElement(login_btn1).click();
}
public void do_login(String emailid1, String password1)

{
	this.before_clickloginbtn_excel();
	this.enter_emailid_excel(emailid1);
	this.enter_password_excel(password1);
	this.clicklogin_btn_excel();
}


	public void enter_text( String productname)
	{
		driver.findElement(pname).sendKeys(productname);

	}
	
	public void clicksearch_btn()
	{
		driver.findElement(search_btn).click();
	}

}
