package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Removecartpage {
	WebDriver driver;
	By book_btn= By.xpath("/html/body/div[4]/div[1]/div[4]/div[1]/div[1]/div[2]/ul/li[1]/a");
	By cart_btn=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[2]/div[3]/div[2]/input");
	By shoppingcart_btn=By.xpath("//*[@id=\"topcartlink\"]/a/span[1]");
	By checkbox_btn = By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/form/table/tbody/tr/td[1]/input");
	By update_btn=By.xpath("/html/body/div[4]/div[1]/div[4]/div/div/div[2]/div/form/div[1]/div/input[1]");
	
public Removecartpage(WebDriver driver) {
		this.driver=driver;
	}
	public void click_books()
	{
		driver.findElement(book_btn).click();
	}
	public void click_cart()
	{
		driver.findElement(cart_btn).click();
	}
	public void click_shoppingcart()
	
	{
		driver.findElement(shoppingcart_btn).click();
	}
	public void click_checkbox()
	{
		driver.findElement(checkbox_btn).click();
		
	}
public void click_updatecart()
{
	driver.findElement(update_btn).click();
}
}
