package com.selutil;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;



public class selutil {
	protected WebDriver driver;
	
	public selutil(WebDriver driver)
	
	{
		//pointing to the current driver
		this.driver= driver;
		
	}
	public void Screenshot(String path) 	{
		//taking the screen shot
		File source=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try
		{
			//copying the screenshot to the specified path
			FileUtils.copyFile(source, new File(path));
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

}
}
