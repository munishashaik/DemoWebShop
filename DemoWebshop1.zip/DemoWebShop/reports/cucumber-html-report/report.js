$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/Features/Testcase.feature");
formatter.feature({
  "line": 2,
  "name": "DemoWebShop",
  "description": "   I want to use this website for my feature file",
  "id": "demowebshop",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@tag"
    }
  ]
});
formatter.scenarioOutline({
  "line": 6,
  "name": "Validating the login functionality",
  "description": "",
  "id": "demowebshop;validating-the-login-functionality",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 5,
      "name": "@tc_01"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "I want to launch the website",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "website is launched",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Click on the login button",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "login page is opened",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "I enter \"\u003cemailid\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "The login button is clicked",
  "keyword": "And "
});
formatter.examples({
  "line": 13,
  "name": "",
  "description": "",
  "id": "demowebshop;validating-the-login-functionality;",
  "rows": [
    {
      "cells": [
        "emailid",
        "password"
      ],
      "line": 14,
      "id": "demowebshop;validating-the-login-functionality;;1"
    },
    {
      "cells": [
        "sk.munisha54@gmail.com",
        "salmamuni54"
      ],
      "line": 15,
      "id": "demowebshop;validating-the-login-functionality;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 15,
  "name": "Validating the login functionality",
  "description": "",
  "id": "demowebshop;validating-the-login-functionality;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@tag"
    },
    {
      "line": 5,
      "name": "@tc_01"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "I want to launch the website",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "website is launched",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Click on the login button",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "login page is opened",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "I enter \"sk.munisha54@gmail.com\" and \"salmamuni54\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "The login button is clicked",
  "keyword": "And "
});
formatter.match({
  "location": "loginstepdef.i_want_to_launch_the_browser()"
});
formatter.result({
  "duration": 12302044786,
  "status": "passed"
});
formatter.match({
  "location": "loginstepdef.website_is_launched()"
});
formatter.result({
  "duration": 867063016,
  "status": "passed"
});
formatter.match({
  "location": "loginstepdef.click_on_the_login_button()"
});
formatter.result({
  "duration": 2011971580,
  "status": "passed"
});
formatter.match({
  "location": "loginstepdef.login_page_is_opened()"
});
formatter.result({
  "duration": 453200862,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "sk.munisha54@gmail.com",
      "offset": 9
    },
    {
      "val": "salmamuni54",
      "offset": 38
    }
  ],
  "location": "loginstepdef.i_enter_and(String,String)"
});
formatter.result({
  "duration": 972285956,
  "status": "passed"
});
formatter.match({
  "location": "loginstepdef.the_login_button_is_clicked()"
});
formatter.result({
  "duration": 2064534553,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 18,
  "name": "Searching for a product",
  "description": "",
  "id": "demowebshop;searching-for-a-product",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 17,
      "name": "@tc_02"
    }
  ]
});
formatter.step({
  "line": 19,
  "name": "I want to launch the searchpage",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "Search page is opened",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "I enter the desired \"\u003cproductname\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "I click the search button",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "The product page is opened",
  "keyword": "And "
});
formatter.examples({
  "line": 24,
  "name": "",
  "description": "",
  "id": "demowebshop;searching-for-a-product;",
  "rows": [
    {
      "cells": [
        "productname"
      ],
      "line": 25,
      "id": "demowebshop;searching-for-a-product;;1"
    },
    {
      "cells": [
        "fiction EX"
      ],
      "line": 26,
      "id": "demowebshop;searching-for-a-product;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 26,
  "name": "Searching for a product",
  "description": "",
  "id": "demowebshop;searching-for-a-product;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@tag"
    },
    {
      "line": 17,
      "name": "@tc_02"
    }
  ]
});
formatter.step({
  "line": 19,
  "name": "I want to launch the searchpage",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "Search page is opened",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "I enter the desired \"fiction EX\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "I click the search button",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "The product page is opened",
  "keyword": "And "
});
formatter.match({
  "location": "searchstepdef.i_want_to_launch_the_browser()"
});
formatter.result({
  "duration": 14497526706,
  "status": "passed"
});
formatter.match({
  "location": "searchstepdef.search_page_is_opened()"
});
formatter.result({
  "duration": 13694793994,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "fiction EX",
      "offset": 21
    }
  ],
  "location": "searchstepdef.i_enter_the_desired(String)"
});
formatter.result({
  "duration": 680068151,
  "status": "passed"
});
formatter.match({
  "location": "searchstepdef.i_click_the_search_button()"
});
formatter.result({
  "duration": 1738846308,
  "status": "passed"
});
formatter.match({
  "location": "searchstepdef.the_product_page_is_opened()"
});
formatter.result({
  "duration": 500232729,
  "status": "passed"
});
formatter.scenario({
  "line": 29,
  "name": "Adding product to  cart",
  "description": "",
  "id": "demowebshop;adding-product-to--cart",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 27,
      "name": "@tc_03"
    }
  ]
});
formatter.step({
  "line": 30,
  "name": "I want to launch categories page",
  "keyword": "Given "
});
formatter.step({
  "line": 31,
  "name": "categories page is launched",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "I click on the books",
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "I click on desired product to add in to cart",
  "keyword": "Then "
});
formatter.step({
  "line": 34,
  "name": "I click on the shopping cart to view the product details",
  "keyword": "And "
});
formatter.match({
  "location": "addtocartstepdef.i_want_to_launch_categories_page()"
});
formatter.result({
  "duration": 12508453953,
  "status": "passed"
});
formatter.match({
  "location": "addtocartstepdef.categories_page_is_launched()"
});
formatter.result({
  "duration": 512698507,
  "status": "passed"
});
formatter.match({
  "location": "addtocartstepdef.i_click_on_the_books()"
});
formatter.result({
  "duration": 1473739041,
  "status": "passed"
});
formatter.match({
  "location": "addtocartstepdef.i_click_on_desired_product_to_add_in_to_cart()"
});
formatter.result({
  "duration": 246251312,
  "status": "passed"
});
formatter.match({
  "location": "addtocartstepdef.i_click_on_the_shopping_cart_to_view_the_product_details()"
});
formatter.result({
  "duration": 1315800196,
  "status": "passed"
});
formatter.scenario({
  "line": 37,
  "name": "Removing product from cart",
  "description": "",
  "id": "demowebshop;removing-product-from-cart",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 36,
      "name": "@tc_04"
    }
  ]
});
formatter.step({
  "line": 38,
  "name": "I launch the homepage",
  "keyword": "Given "
});
formatter.step({
  "line": 39,
  "name": "page is launched and  I click on the books",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "I add a product in the cart and click on the shopping cart",
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "cart is opened and I select an item to delete",
  "keyword": "Then "
});
formatter.step({
  "line": 42,
  "name": "I click on the update shopping cart",
  "keyword": "And "
});
formatter.match({
  "location": "removecartstepdef.i_launch_the_homepage()"
});
formatter.result({
  "duration": 18230411856,
  "status": "passed"
});
formatter.match({
  "location": "removecartstepdef.page_is_launched_and_I_click_on_the_books()"
});
formatter.result({
  "duration": 2483614773,
  "status": "passed"
});
formatter.match({
  "location": "removecartstepdef.i_add_a_product_in_the_cart_and_click_on_the_shopping_cart()"
});
formatter.result({
  "duration": 1377259233,
  "status": "passed"
});
formatter.match({
  "location": "removecartstepdef.cart_is_opened_and_I_select_an_item_to_delete()"
});
formatter.result({
  "duration": 2328426087,
  "status": "passed"
});
formatter.match({
  "location": "removecartstepdef.i_click_on_the_update_shopping_cart()"
});
formatter.result({
  "duration": 1223163632,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 45,
  "name": "Newsletter subscribption",
  "description": "",
  "id": "demowebshop;newsletter-subscribption",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 44,
      "name": "@tc_05"
    }
  ]
});
formatter.step({
  "line": 46,
  "name": "I launch the homepage1",
  "keyword": "Given "
});
formatter.step({
  "line": 47,
  "name": "I enter the \"\u003cemailid\u003e\" in the newsletter section of homepage",
  "keyword": "When "
});
formatter.step({
  "line": 48,
  "name": "I click subscribe option",
  "keyword": "Then "
});
formatter.examples({
  "line": 49,
  "name": "",
  "description": "",
  "id": "demowebshop;newsletter-subscribption;",
  "rows": [
    {
      "cells": [
        "emailid"
      ],
      "line": 50,
      "id": "demowebshop;newsletter-subscribption;;1"
    },
    {
      "cells": [
        "sk.munisha54@gmail.com"
      ],
      "line": 51,
      "id": "demowebshop;newsletter-subscribption;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 51,
  "name": "Newsletter subscribption",
  "description": "",
  "id": "demowebshop;newsletter-subscribption;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 44,
      "name": "@tc_05"
    },
    {
      "line": 1,
      "name": "@tag"
    }
  ]
});
formatter.step({
  "line": 46,
  "name": "I launch the homepage1",
  "keyword": "Given "
});
formatter.step({
  "line": 47,
  "name": "I enter the \"sk.munisha54@gmail.com\" in the newsletter section of homepage",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 48,
  "name": "I click subscribe option",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 21
    }
  ],
  "location": "newsletterpagestepdef.i_launch_the_homepage(int)"
});
formatter.result({
  "duration": 17363417094,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "sk.munisha54@gmail.com",
      "offset": 13
    }
  ],
  "location": "newsletterpagestepdef.i_enter_the_in_the_newsletter_section_of_homepage(String)"
});
formatter.result({
  "duration": 1095313850,
  "status": "passed"
});
formatter.match({
  "location": "newsletterpagestepdef.i_click_subscribe_option()"
});
formatter.result({
  "duration": 203777555,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 54,
  "name": "logging out",
  "description": "",
  "id": "demowebshop;logging-out",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 53,
      "name": "@tc_06"
    }
  ]
});
formatter.step({
  "line": 55,
  "name": "I launch the website homepage",
  "keyword": "Given "
});
formatter.step({
  "line": 56,
  "name": "page will open and I login with \"\u003cemailid\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 57,
  "name": "login page will be opened and I click on logout button",
  "keyword": "Then "
});
formatter.examples({
  "line": 58,
  "name": "",
  "description": "",
  "id": "demowebshop;logging-out;",
  "rows": [
    {
      "cells": [
        "emailid",
        "password"
      ],
      "line": 59,
      "id": "demowebshop;logging-out;;1"
    },
    {
      "cells": [
        "sk.munisha54@gmail.com",
        "salmamuni54"
      ],
      "line": 60,
      "id": "demowebshop;logging-out;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 60,
  "name": "logging out",
  "description": "",
  "id": "demowebshop;logging-out;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 53,
      "name": "@tc_06"
    },
    {
      "line": 1,
      "name": "@tag"
    }
  ]
});
formatter.step({
  "line": 55,
  "name": "I launch the website homepage",
  "keyword": "Given "
});
formatter.step({
  "line": 56,
  "name": "page will open and I login with \"sk.munisha54@gmail.com\" and \"salmamuni54\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 57,
  "name": "login page will be opened and I click on logout button",
  "keyword": "Then "
});
formatter.match({
  "location": "logoutpagestepdef.i_launch_the_website_homepage()"
});
formatter.result({
  "duration": 24685100956,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "sk.munisha54@gmail.com",
      "offset": 33
    },
    {
      "val": "salmamuni54",
      "offset": 62
    }
  ],
  "location": "logoutpagestepdef.page_will_open_and_I_login_with_and(String,String)"
});
formatter.result({
  "duration": 4399312333,
  "status": "passed"
});
formatter.match({
  "location": "logoutpagestepdef.login_page_will_be_opened_and_I_click_on_logout_button()"
});
formatter.result({
  "duration": 2424908975,
  "status": "passed"
});
});