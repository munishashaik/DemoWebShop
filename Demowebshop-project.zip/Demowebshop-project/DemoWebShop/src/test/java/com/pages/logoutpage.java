package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class logoutpage {
	WebDriver driver;
	By eid=By.id("Email");
	By pwd=By.id("Password");
	By login_btn= By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input");
	By before_loginbtn=By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a");
	By logout_btn= By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a");
	public logoutpage(WebDriver driver)
	{
		this.driver= driver;
	}
	public void before_clickloginbtn()
	{
		driver.findElement(before_loginbtn).click();
	}
public void enter_emailid(String emailid)
{
	driver.findElement(eid).sendKeys(emailid);
}
public void enter_password(String password)
{
	driver.findElement(pwd).sendKeys(password);
}
public void clicklogin_btn()
{
	driver.findElement(login_btn).click();
}
public void clicklogout_btn()
{
	driver.findElement(logout_btn).click();
}

}
