package com.stepdef;

import org.apache.log4j.Logger;

import com.baseclass.library;
import com.pages.Removecartpage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class removecartstepdef extends library {
	Removecartpage Rcp;
	Logger LOG = Logger.getLogger("devpinoyLogger");
	@Given("^I launch the homepage$")
	public void i_launch_the_homepage() throws Throwable {
		LaunchBrowser();
		System.out.println("browser is launched");
		LOG.info("the website is launched");

	
	 
	}

	@When("^page is launched and  I click on the books$")
	public void page_is_launched_and_I_click_on_the_books() throws Throwable {
		Rcp= new Removecartpage(driver);
		Rcp.click_books();
		LOG.info("the books button is clicked");
		
		
	  
	}

	@Then("^I add a product in the cart and click on the shopping cart$")
	public void i_add_a_product_in_the_cart_and_click_on_the_shopping_cart() throws Throwable {
		Rcp= new Removecartpage(driver);
		Rcp.click_cart();
	Rcp.click_shoppingcart();
	LOG.info("the product is added to cart");
	LOG.info(" the product details are displayed");

	  
	    
	}

	@Then("^cart is opened and I select an item to delete$")
	public void cart_is_opened_and_I_select_an_item_to_delete() throws Throwable {
		Rcp= new Removecartpage(driver);
		Rcp.click_shoppingcart();
	Rcp.click_checkbox();
			
	 
	}

	@Then("^I click on the update shopping cart$")
	public void i_click_on_the_update_shopping_cart() throws Throwable {
		Rcp= new Removecartpage(driver);
		Rcp.click_updatecart();
		LOG.info("the product is deleted  from the cart");
	    
	}



}
