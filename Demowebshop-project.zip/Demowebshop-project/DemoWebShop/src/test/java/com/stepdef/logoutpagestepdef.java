package com.stepdef;

import org.apache.log4j.Logger;

import com.baseclass.library;
import com.pages.logoutpage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class logoutpagestepdef extends library {
	logoutpage lop;
	Logger LOG = Logger.getLogger("devpinoyLogger");
	@Given("^I launch the website homepage$")
public void i_launch_the_website_homepage() throws Throwable {
		LaunchBrowser();
		System.out.println("browser is launched");
		LOG.info("the website is launched");
		
	
}


	@When("^page will open and I login with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void page_will_open_and_I_login_with_and(String emailid, String password) throws Throwable {
		lop=new logoutpage(driver);
		lop.before_clickloginbtn();
		lop.enter_emailid(emailid);
		lop.enter_password(password);
		lop.clicklogin_btn();
		LOG.info("login is sucessful");
	  
	}

	@Then("^login page will be opened and I click on logout button$")
	public void login_page_will_be_opened_and_I_click_on_logout_button() throws Throwable {
		
		lop=new logoutpage(driver);
		lop.clicklogout_btn();
		LOG.info("logout button is clicked");
	}

	}
