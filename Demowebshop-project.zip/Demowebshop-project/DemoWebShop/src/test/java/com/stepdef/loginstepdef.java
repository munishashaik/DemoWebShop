package com.stepdef;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.baseclass.library;
import com.pages.loginpage;
import com.selutil.selutil;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class loginstepdef extends library {
	
	
	selutil util;
	
	loginpage lp;
Logger LOG = Logger.getLogger("devpinoyLogger");
	
	@Given("^I want to launch the website$")
	public void i_want_to_launch_the_browser() throws Throwable {
		 
	LaunchBrowser();
		System.out.println("browser is launched");
		
	   }
@When("^website is launched$")
	public void website_is_launched() throws Throwable {
	selutil util;
		util= new selutil(driver);
		util.Screenshot("C:\\Users\\lenovo\\Desktop\\munisha\\selenium\\DemoWebShop\\src\\test\\resources\\Screenshots\\websitepage.png");
	    System.out.println("screenshot is successfully taken");
	    LOG.info("screenshot is taken successfully");
	    
	    }
	@Then("^Click on the login button$")
public void click_on_the_login_button() {
		lp= new loginpage(driver);
		lp.before_clickloginbtn();
		
	      
	}
	@Then("^login page is opened$")
	public void login_page_is_opened()  {
		selutil util;
		util= new selutil(driver);
		util.Screenshot("C:\\Users\\lenovo\\Desktop\\munisha\\selenium\\DemoWebShop\\src\\test\\resources\\Screenshots\\loginpage.png");
	    System.out.println("screenshot is successfully taken");
	      
	      }
@Then("^I enter \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_enter_and(String emailid, String password) {
		 lp= new loginpage(driver);
	lp.enter_emailid(emailid);
	lp.enter_password(password);
	LOG.info("emailid and password entered");
	     }
@Then("^The login button is clicked$")
public void the_login_button_is_clicked() {
lp= new loginpage(driver);
lp.clicklogin_btn();
LOG.info("login sucessful");
    
}




}
