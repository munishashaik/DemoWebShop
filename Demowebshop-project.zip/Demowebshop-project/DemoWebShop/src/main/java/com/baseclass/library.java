package com.baseclass;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class library {

	protected WebDriver driver;
	Properties prop;
	
	
	//launching a WebBrowser
	public void LaunchBrowser() throws IOException
	{
		//locating the path of the file
		FileInputStream  obj=new FileInputStream("C:\\Users\\lenovo\\Desktop\\munisha\\selenium\\DemoWebShop\\src\\test\\resources\\config.property\\configuration.property");
		//creating the object to the property files
		prop = new Properties();
		//loading the property file into the object
		prop.load(obj);
		//initializing the browser name
		String browserName= prop.getProperty("browser");
		try {
			//checking the browser name
			if (browserName.equalsIgnoreCase("chrome"))
			{
				//setting the Chrome driver property
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\lenovo\\Desktop\\munisha\\selenium\\DemoWebShop\\src\\test\\resources\\Drivers\\chromedriver.exe");
						//initializing the driver
						driver= new ChromeDriver();
			} //checking the browser name
			 else if (browserName.equalsIgnoreCase("firefox")) {
				 //Initializing the browser
				 driver = new FirefoxDriver();
			
			 }
			//maximize the window
			 driver.manage().window().maximize();
			 // Implicitly waiting the driver
			 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			 //getting the url from the property file
			 driver.get(prop.getProperty("url"));
			
			
			
			

			}
				catch(WebDriverException e)
		{
					//printing the message
					System.out.println("browser could not be launched");
		}
		
	}
	
}
