$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/Features/Testcase.feature");
formatter.feature({
  "line": 2,
  "name": "DemoWebShop",
  "description": "   I want to use this website for my feature file",
  "id": "demowebshop",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@tag"
    }
  ]
});
formatter.scenarioOutline({
  "line": 6,
  "name": "Validating the login functionality",
  "description": "",
  "id": "demowebshop;validating-the-login-functionality",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 5,
      "name": "@tc_01"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "I want to launch the website",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "website is launched",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Click on the login button",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "login page is opened",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "I enter \"\u003cemailid\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "The login button is clicked",
  "keyword": "And "
});
formatter.examples({
  "line": 13,
  "name": "",
  "description": "",
  "id": "demowebshop;validating-the-login-functionality;",
  "rows": [
    {
      "cells": [
        "emailid",
        "password"
      ],
      "line": 14,
      "id": "demowebshop;validating-the-login-functionality;;1"
    },
    {
      "cells": [
        "sk.munisha54@gmail.com",
        "salmamuni54"
      ],
      "line": 15,
      "id": "demowebshop;validating-the-login-functionality;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 15,
  "name": "Validating the login functionality",
  "description": "",
  "id": "demowebshop;validating-the-login-functionality;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@tag"
    },
    {
      "line": 5,
      "name": "@tc_01"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "I want to launch the website",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "website is launched",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Click on the login button",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "login page is opened",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "I enter \"sk.munisha54@gmail.com\" and \"salmamuni54\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "The login button is clicked",
  "keyword": "And "
});
formatter.match({
  "location": "loginstepdef.i_want_to_launch_the_browser()"
});
formatter.result({
  "duration": 105126466234,
  "status": "passed"
});
formatter.match({
  "location": "loginstepdef.website_is_launched()"
});
